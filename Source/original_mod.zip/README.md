# Star Wars - The Force
Adds the force to RimWorld. Jedi, Sith, and even Gray Jedi can be utilized to help defend your colonies, or destroy them.

**This mod requires JecsTools to run properly.**
https://github.com/jecrell/JecsTools
