﻿using Verse;

namespace ProjectJedi
{
    [StaticConstructorOnStartup]
    public static class ModInfo
    {
        public static float forceXPDelayFactor = 1;
    }
}