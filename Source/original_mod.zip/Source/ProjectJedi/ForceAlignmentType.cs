﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ProjectJedi
{
    public enum ForceAlignmentType : byte
    {
        None,
        Light,
        Gray,
        Dark
    }
}
