﻿using Verse;

namespace ProjectJedi
{
    [StaticConstructorOnStartup]
    public static class ModInfo
    {
        public static bool TutorLesson_Sensitive = false;
        public static bool TutorLesson_OtherForce = false;
        public static float forceXPDelayFactor = 1;
    }
}