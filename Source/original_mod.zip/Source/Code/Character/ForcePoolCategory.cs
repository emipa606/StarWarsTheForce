﻿namespace ProjectJedi
{
    public enum ForcePoolCategory
    {
        Drained,
        Feeble,
        Steady,
        Strong,
        Surging
    }
}