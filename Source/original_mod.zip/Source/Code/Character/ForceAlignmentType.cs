﻿namespace ProjectJedi
{
    public enum ForceAlignmentType : byte
    {
        None,
        Light,
        Gray,
        Dark
    }
}